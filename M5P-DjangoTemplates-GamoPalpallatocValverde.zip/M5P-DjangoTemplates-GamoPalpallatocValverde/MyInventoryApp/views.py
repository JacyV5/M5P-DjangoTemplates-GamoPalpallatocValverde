from django.shortcuts import render
from .models import Supplier, WaterBottle

# Create your views here.
def list_template(request):
	Supplier_objects = Supplier.objects.all()
	WaterBottle_objects = WaterBottle.objects.all()
	return render(request, 'myapp/list_template.html', {'Supplier':Supplier_objects, 'WaterBottle':WaterBottle_objects})

def view_supplier(request):
	Supplier_objects = Supplier.objects.all()
	WaterBottle_objects = WaterBottle.objects.all()
	return render(request, 'myapp/supplier_list.html', {'Supplier':Supplier_objects, 'WaterBottle':WaterBottle_objects})

def view_bottles(request):
	Supplier_objects = Supplier.objects.all()
	WaterBottle_objects = WaterBottle.objects.all()
	return render(request, 'myapp/view_bottles.html', {'Supplier':Supplier_objects, 'WaterBottle':WaterBottle_objects})

def add_bottle(request):
	Supplier_objects = Supplier.objects.all()
	WaterBottle_objects = WaterBottle.objects.all()
	return render(request, 'myapp/add_bottle.html', {'Supplier':Supplier_objects, 'WaterBottle':WaterBottle_objects})
