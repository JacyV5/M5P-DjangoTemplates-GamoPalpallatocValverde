from django.db import models

from django.db import models
from django.utils import timezone

class Supplier(models.Model):
    name = models.CharField(max_length=300, blank=True, null=True)
    city = models.CharField(max_length=300, blank=True, null=True) 
    #Error in migration w/o the default
    country = models.CharField(max_length=300, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    objects = models.Manager()

    def getName(self):
        return self.name
        
    def __str__(self):
        return f"{self.name} - {self.city}, {self.country} {self.created_at}"

class WaterBottle(models.Model):
    #No repeating SKUs = unique
    sku = models.CharField(max_length=3, unique=True, blank=True, null=True)
    brand = models.CharField(max_length=300, blank=True, null=True)
    cost = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    size = models.CharField(max_length=300, blank=True, null=True)
    mouth_size = models.CharField(max_length=300, blank=True, null=True)
    color = models.CharField(max_length=300, blank=True, null=True)
    #Refers to Supplier model
    supplied_by = models.ForeignKey(Supplier, on_delete=models.CASCADE, blank=True, null=True)
    current_quantity = models.PositiveIntegerField(blank=True, null=True)
        #There was an error with max_length so I removed it
    objects = models.Manager()

    def __str__(self):
        return f"{self.sku}:{self.brand}, {self.mouth_size}, {self.size}, {self.color}, supplied by {self.supplied_by}, {self.cost} : {self.current_quantity}"



#Business Rules pertaining to Supplier & Water Bottle
#WaterBottles are identified using an SKU
# Supplier can supply MULTIPLE SKUs
# 1 SKU = 1 Supplier

# Create your models here.

#Sources:
#For Decimal Field
#https://docs.djangoproject.com/en/3.0/ref/models/fields/#field-types

